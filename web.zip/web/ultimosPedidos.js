const datosUltimosPedidos = fetch('http://192.168.1.147:3000/pedidos')
.then(response => response.json())
.then(data => mostrarDatos(data))
const buscar = document.getElementById("buscar");

const mostrarDatos = (data) => {
    console.log(data)
    let ultimosPedidos = document.getElementById("ultimosPedidos");
    for (let i = 0; i <= data.length; i++){
        ultimosPedidos.innerHTML += `<p>Información del último pedido: <br>
        id del cliente: ${data[i].id_cliente}<br>
        id del producto: ${data[i].id_producto}<br>
        nombre del cliente: ${data[i].nombre_cliente}<br>
        fecha: ${data[i].fecha}<br>
        Estado: ${data[i].estado}<br>
        Cantidad total: ${data[i].coste_total}<br>
        </p>
        `
    }
} 
buscar.addEventListener("click", ()=>{
    let busqueda = document.getElementById("busqueda").value;
    location.href = `http://192.168.1.147:3000/productos/${busqueda}`
})
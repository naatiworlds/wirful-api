const formElement = document.getElementById("productos");
const buscar = document.getElementById("buscar");

formElement.addEventListener("submit", (event) => {
    event.preventDefault();
    let nombre = document.getElementById("Nombre").value;
    let id = document.getElementById("id").value;
    let coste = document.getElementById("coste").value;
    let cantidad = document.getElementById("cantidad").value;
    let idInt = parseInt(id);
    let costeInt = parseInt(coste);
    let cantidadInt = parseInt(cantidad);

    let data = { id: idInt, nombre: nombre, coste: costeInt, cantidad: cantidadInt };
    let dataJson = JSON.stringify(data);


    fetch('http://192.168.1.147:3000/productos', {
        method: 'Post',
        body: dataJson
    })
})

buscar.addEventListener("click", ()=>{
    let busqueda = document.getElementById("busqueda").value;
    location.href = `http://192.168.1.147:3000/productos/${busqueda}`
})

fetch('http://192.168.1.147:3000/productos').then(x => x.json()).then(x=>console.log)
const formElement = document.getElementById("pedidos");
const datosPedidos = fetch('http://192.168.1.147:3000/pedidos')
.then(response => response.json())
.then(data => mostrarDatos(data))
const buscar = document.getElementById("buscar")

formElement.addEventListener("submit", (event) => {
    event.preventDefault();
    let id_cliente = document.getElementById("id_cliente").value;
    let id_producto = document.getElementById("id_producto").value;
    let nombre_cliente = document.getElementById("nombre_cliente").value;
    let fecha = document.getElementById("fecha").value;
    let estado = document.getElementById("estado").value;
    let coste_total = document.getElementById("coste_total").value;
    

    let data = { 
        id_cliente: id_cliente, 
        id_producto: id_producto,  
        nombre_cliente: nombre_cliente,
        fecha: fecha,
        estado: estado, 
        coste_total: coste_total
    };
    let dataJson = JSON.stringify(data);


    fetch('http://192.168.1.147:3000/pedidos', {
        method: 'Post',
        body: dataJson
    })
})
function mostrarDatos (data){
    buscar.addEventListener("click", () => {
        let Pedidos = document.getElementById("Pedidos");
        let busqueda = document.getElementById("busqueda").value;
        for (let i = 0; i <= data.length; i++){
            if(data[i].nombre_cliente.toLowerCase() == busqueda.toLowerCase()){
                Pedidos.innerHTML += `<div class="card">
                <h2>Pedido de: ${data[i].nombre_cliente}</h2>
                <p>Información del último pedido: <br>
                id del cliente: ${data[i].id_cliente}<br>
                id del producto: ${data[i].id_producto}<br>
                nombre del cliente: ${data[i].nombre_cliente}<br>
                fecha: ${data[i].fecha}<br>
                Estado: ${data[i].estado}<br>
                Cantidad total: ${data[i].coste_total}<br></p>
                </div>
                `
                
            }
        }
    })
}
 
    
